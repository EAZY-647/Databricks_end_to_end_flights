# Databricks notebook source
# MAGIC %sql
# MAGIC create volume workspace.raw.rawvolume

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/rawdata/airports")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/workspace/bronze/bronzevolume/flights/data/`

# COMMAND ----------

# MAGIC %md
# MAGIC